print("Hello, World!")
print("My name is Minh")
print("HUTECH University")