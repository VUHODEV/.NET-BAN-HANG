ban_kinh = float(input("Nhập bán kính hình tròn: "))
dien_tich = 3.14 * (ban_kinh ** 2)
print("Diện tích của hình tròn là :", dien_tich)