so = int(input("Nhập một số nguyên: "))
if so % 2 == 0:
    print(so, " là số chẵn.")
else:
    print(so, "không phải là số chẵn.")