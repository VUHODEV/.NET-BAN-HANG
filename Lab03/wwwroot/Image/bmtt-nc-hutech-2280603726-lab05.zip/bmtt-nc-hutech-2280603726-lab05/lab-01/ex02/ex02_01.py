ten = input("Nhập tên của bạn: ")
tuoi = input("Nhập tuổi của bạn: ")
print("Chào Mừng, " + ten + "! Bạn " + tuoi + " tuổi")